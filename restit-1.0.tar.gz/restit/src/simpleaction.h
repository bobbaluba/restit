#ifndef SIMPLEACTION_H
#define SIMPLEACTION_H

struct SimpleAction{
    int rotation;
    int position;
};

#endif // SIMPLEACTION_H
